// [startId, endId, icon] of a group

exports.ids = [
    [0, 385, '😄'], // Smileys
    [386, 1783, '👷'], // People
    [1784, 1888, '🐶'], // Animals
    [1889, 1910, '🌻'], // Flowers
    [1911, 2030, '🍕'], // Food
    [2031, 2194, '🏘️'], // Places
    [2195, 2245, '☁️'], // Weather
    [2246, 2550, '♟️'], // Activities
    [2551, 2763, '▶️'], // Symbols
    [2764, 3031, '🏴'], // Flags
    [0, 3031] //Clear category
]